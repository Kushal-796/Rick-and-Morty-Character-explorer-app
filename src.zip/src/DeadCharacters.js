// src/DeadCharacters.js
import React from 'react';

const deadCharacters = [
  {
    id: 6,
    name: 'Mr. Poopybutthole',
    image: 'https://rickandmortyapi.com/api/character/avatar/244.jpeg'
  },
  {
    id: 7,
    name: 'Birdperson',
    image: 'https://rickandmortyapi.com/api/character/avatar/47.jpeg'
  },
  {
    id: 8,
    name: 'Abradolf Lincler',
    image: 'https://rickandmortyapi.com/api/character/avatar/39.jpeg'
  }
];

function DeadCharacters() {
  return (
    <div>
      <h1>Dead Characters</h1>
      <div className="character-list">
        {deadCharacters.map(character => (
          <div key={character.id} className="character-card">
            <img src={character.image} alt={character.name} />
            <h2>{character.name}</h2>
          </div>
        ))}
      </div>
    </div>
  );
}

export default DeadCharacters;
