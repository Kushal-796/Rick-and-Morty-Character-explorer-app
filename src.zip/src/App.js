import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import AllCharacters from './AllCharacters';
import CharacterDetail from './CharacterDetail';
import AliveCharacters from './AliveCharacters'; // Import this
import DeadCharacters from './DeadCharacters'; // Import this

function App() {
  return (
    <Router>
      <div className="app-container">
        <header className="app-header">Rick and Morty Character Explorer App</header>
        <div className="button-container">
          <Link to="/all-characters">
            <button className="custom-button">All Characters</button>
          </Link>
          <Link to="/alive-characters">
            <button className="custom-button">Alive Characters</button>
          </Link>
          <Link to="/dead-characters">
            <button className="custom-button">Dead Characters</button>
          </Link>
        </div>
        <Routes>
          <Route path="/all-characters" element={<AllCharacters />} />
          <Route path="/alive-characters" element={<AliveCharacters />} />
          <Route path="/dead-characters" element={<DeadCharacters />} />
          <Route path="/character/:id" element={<CharacterDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
