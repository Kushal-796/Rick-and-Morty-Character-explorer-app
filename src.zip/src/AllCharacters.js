import React from 'react';
import { Link } from 'react-router-dom';
import './App.css';

// Include image URLs for each character
const characters = [
  {
    id: '1',
    name: 'Rick Sanchez',
    universe: 'C-137',
    details: 'A genius scientist with a reckless and cynical attitude.',
    image: 'https://rickandmortyapi.com/api/character/avatar/1.jpeg'
  },
  {
    id: '2',
    name: 'Morty Smith',
    universe: 'C-137',
    details: 'Rick\'s good-hearted but easily influenced grandson.',
    image: 'https://rickandmortyapi.com/api/character/avatar/2.jpeg'
  },
  {
    id: '3',
    name: 'Summer Smith',
    universe: 'C-137',
    details: 'Morty\'s older sister, who occasionally joins Rick and Morty on their adventures.',
    image: 'https://rickandmortyapi.com/api/character/avatar/3.jpeg'
  },
  {
    id: '4',
    name: 'Beth Smith',
    universe: 'C-137',
    details: 'Rick\'s daughter and Morty\'s mother, who works as a horse surgeon.',
    image: 'https://rickandmortyapi.com/api/character/avatar/4.jpeg'
  },
  {
    id: '5',
    name: 'Jerry Smith',
    universe: 'C-137',
    details: 'Morty\'s insecure and often clueless father.',
    image: 'https://rickandmortyapi.com/api/character/avatar/5.jpeg'
  },
  {
    id: '6',
    name: 'Poopy Butthole',
    universe: 'Unknown',
    details: 'A recurring character known for his quirky behavior.',
    image: 'https://rickandmortyapi.com/api/character/avatar/244.jpeg'
  },
  {
    id: '7',
    name: "BirdPerson",
    universe: "Unknown",
    details: 'A member of the Galactic Federation and ally to Rick and Morty.',
    image: 'https://rickandmortyapi.com/api/character/avatar/47.jpeg'
  },
  {
    id: '8',
    name: "Abradolf Lincler",
    universe: 'Unknown',
    details: 'A hybrid clone created from Abraham Lincoln and Adolf Hitler.',
    image: 'https://rickandmortyapi.com/api/character/avatar/39.jpeg'
  }
];

function AllCharacters() {
  return (
    <div className="character-list">
      {characters.map((character) => (
        <div key={character.id} className="character-card">
          <Link to={`/character/${character.id}`}>
            <img src={character.image} alt={character.name} className="character-image"/>
            <h2 className="character-name">{character.name}</h2>
          </Link>
        </div>
      ))}
    </div>
  );
}

export default AllCharacters;
