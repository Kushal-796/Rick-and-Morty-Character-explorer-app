import React from 'react';
import { useParams } from 'react-router-dom';
import './App.css';

// Example hardcoded character data
const characters = {
  '1': {
    id: '1',
    name: 'Rick Sanchez',
    image: 'https://rickandmortyapi.com/api/character/avatar/1.jpeg',
    status: 'Alive',
    species: "Human",
    gender: 'Male',
    details: 'A genius scientist with a reckless and cynical attitude.',
    origin: 'Earth (C-137)',
    universe: 'Earth (Replacement Dimension)',
    episodes: ['1', '2', '3', '4', '5'], // Example episode numbers
  },
  '2': {
    id: '2',
    name: 'Morty Smith',
    image: 'https://rickandmortyapi.com/api/character/avatar/2.jpeg',
    status: 'Alive',
    species: "Human",
    gender: 'Male',
    details: 'Rick\'s good-hearted but easily influenced grandson.',
    origin: 'Earth (C-137)',
    universe: 'Earth (Replacement Dimension)',
    episodes: ['1', '2', '3', '4', '5'], // Example episode numbers
  },
  '3': {
    id: '3',
    name: 'Summer Smith',
    image: 'https://rickandmortyapi.com/api/character/avatar/3.jpeg',
    status: 'Alive',
    species: "Human",
    gender: 'Female',
    details: 'Morty\'s older sister, who occasionally joins Rick and Morty on their adventures.',
    origin: 'Earth (C-137)',
    universe: 'Earth (Replacement Dimension)',
    episodes: ['Season-1:', '1', '6', '7', '8', '9'], // Example episode numbers
  },
  '4':{
    id:'4',
    name: 'Berth Smith',
    image: 'https://rickandmortyapi.com/api/character/avatar/4.jpeg',
    status: 'Alive',
    species: 'Human',
    gender: 'Female',
    details: 'Rick\'s daughter and Morty\'s mother, who works as a horse surgeon.',
    origin: 'Earth (Replacement Dimension)',
    universe: 'Earth (Replacement Dimension)',
    episodes: ['1','2','3','4','5','6','and more']
  },
  '5':{
    id:'5',
    name:'Jerry Smith',
    image: 'https://rickandmortyapi.com/api/character/avatar/5.jpeg',
    status: 'Alive',
    species: 'Human',
    gender: 'Male',
    details: 'Morty\'s insecure and often clueless father.',
    origin: 'Earth-C137',
    universe: 'Earth (Replacement Dimension',
    episodes: ['1','2','3','4','5','and more']
  },
  '6':{
    id: '6',
    name: "Poopy Butthole",
    image: 'https://rickandmortyapi.com/api/character/avatar/244.jpeg',
    status: "Dead",
    species: "Human (Appears as a Different Species",
    gender: 'Male',
    origin: 'Unknown',
    universe: 'Unknown',
    episodes: ["S02E04","S03E06","S04E06","S04E02","S05E01","S05E10"]
  },
  '7':{
    id: '7',
    name: 'BirdPerson',
    image: 'https://rickandmortyapi.com/api/character/avatar/47.jpeg',
    status: "Dead",
    species: "BirdPerson",
    gender: "Male",
    origin: "Unknown",
    Location: "Unknown",
    episodes: ["S01E11","S02E10","S03E07","S04E05"]
  },
  '8':{
    id:'8',
    name: "Abradolf Lincler",
    image: "https://rickandmortyapi.com/api/character/avatar/39.jpeg",
    status: "Dead",
    species: "Human",
    gender: "Male",
    origin: "Unknown",
    location: "Unknown",
    episodes: ["S02E01"]
  }
  
};

function CharacterDetail() {
  const { id } = useParams();
  const character = characters[id];

  if (!character) return <p>Character not found</p>;

  return (
    <div className="character-detail">
      <img src={character.image} alt={character.name} className="character-image" />
      <h1>{character.name}</h1>
      <p><strong>Status:</strong> {character.status}</p>
      <p><strong>Species:</strong>{character.species}</p>
      <p><strong>Gender:</strong> {character.gender}</p>
      <p><strong>Details:</strong> {character.details}</p>
      <p><strong>Origin:</strong> {character.origin}</p>
      <p><strong>Universe:</strong> {character.universe}</p>
      <h2>Episodes</h2>
      <ul>
        {character.episodes.map((episode, index) => (
          <li key={index}>Episode {episode}</li>
        ))}
      </ul>
    </div>
  );
}

export default CharacterDetail;
